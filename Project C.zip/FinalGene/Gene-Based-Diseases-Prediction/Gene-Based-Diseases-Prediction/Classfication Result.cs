﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Robust_Model_Based_Learning_Spatial_EM_Algorithm
{
    public partial class Classfication_Result : Form
    {
        public Classfication_Result()
        {
            InitializeComponent();
        }
    }
}
