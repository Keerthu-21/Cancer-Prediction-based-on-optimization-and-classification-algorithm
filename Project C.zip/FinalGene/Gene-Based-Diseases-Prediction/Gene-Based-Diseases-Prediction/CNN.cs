﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;


namespace GeneBasedDiseasesPrediction
{
    public partial class CNN : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\FinalGene\Gene-Based-Diseases-Prediction\Gene-Based-Diseases-Prediction\data.mdf;Integrated Security=True;User Instance=True");
        SqlCommand cmd;
        public string file;
        public string kn,n;
        

        public CNN()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = file;
            StreamReader sr = new StreamReader(path + "newdataset.txt");
            richTextBox2.Text = sr.ReadToEnd();

            cnncalssfication hh = new cnncalssfication();
            hh.n = n;
            hh.Show();


            cnnClassficationResult kk=new cnnClassficationResult ();
            kk.n = n;
            kk.Show();


        }


        string path;

        private void KNN_Load(object sender, EventArgs e)
        {
            path = System.IO.Path.GetDirectoryName(Application.ExecutablePath.ToString()) + "\\datase\\";
        }



    }
}




    