﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Windows.Forms.DataVisualization.Charting;

namespace GeneBasedDiseasesPrediction
{
    public partial class cnnClassficationResult : Form
    {
        public string n;
        public cnnClassficationResult()
        {
            InitializeComponent();
        }

        private void KnnClassficationResult_Load(object sender, EventArgs e)
        {
            //chart1.Series["Unsupervised"].ChartType = SeriesChartType.Line;
            //chart1.Series["Supervised"].ChartType = SeriesChartType.Line;
            //chart1.Series["Semisupervised"].ChartType = SeriesChartType.Line;
            BindChart();
        }

        private void BindChart()
        {
            string conString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\FinalGene\Gene-Based-Diseases-Prediction\Gene-Based-Diseases-Prediction\data.mdf;Integrated Security=True;User Instance=True";
            SqlConnection conn = new SqlConnection(conString);
            DataSet ds = new DataSet();
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM result1", conn);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                da.Fill(ds, "Result");
                chart1.DataSource = ds.Tables["Result"];
                chart1.Series["Result"].XValueMember = "name";
                chart1.Series["Result"].YValueMembers = "Result";

               
                // Set the chart title
                this.chart1.Titles.Add("CNN CLASSIFICATION");
                //// Set chart type like Bar chart, Pie chart 
                chart1.Series["Result"].ChartType = SeriesChartType.Pie;
               // To show chart value           
                chart1.Series["Result"].IsValueShownAsLabel = true;
                //chart1.Series["Series2"].IsValueShownAsLabel = true;
               ////label1.Text = n;


               //conn.Open();
               //SqlCommand cmd1 = new SqlCommand("SELECT * FROM result1", conn);
               //SqlDataReader dr = cmd.ExecuteReader();
               //if (dr.Read())
               //{
               //    sqlda

               //}










            }
            catch (Exception ex)
            {
                //Exception Message
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }




        }
    }
}
