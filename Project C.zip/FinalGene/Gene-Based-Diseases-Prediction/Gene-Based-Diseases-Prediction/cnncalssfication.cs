﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using weka.classifiers;
using System.Data.SqlClient;



namespace GeneBasedDiseasesPrediction
{
    public partial class cnncalssfication : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\FinalGene\Gene-Based-Diseases-Prediction\Gene-Based-Diseases-Prediction\data.mdf;Integrated Security=True;User Instance=True");
        SqlCommand cmd;
        Double tt;

        public string n;

        const int percentSplit = 66;
        const int percent = 69;
        string  gag, tga;
        public cnncalssfication()
        {
            InitializeComponent();
        }
        string path;

        private void knncalssfication_Load(object sender, EventArgs e)
        {
            path = System.IO.Path.GetDirectoryName(Application.ExecutablePath.ToString()) + "\\datase\\";

            this.button1.PerformClick();
            this.button2.PerformClick();
            this.button3.PerformClick();
            chartdata();

        }


        int ttt;

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                weka.core.Instances insts = new weka.core.Instances(new java.io.FileReader(path + "newdataset1.txt"));
                insts.setClassIndex(insts.numAttributes() - 1);

                weka.classifiers.Classifier cl = new weka.classifiers.trees.J48();
                //Console.WriteLine("Performing " + percentSplit + "% split evaluation.");
                //label1.Text = ("Performing " + percentSplit + "% split evaluation.");

                //randomize the order of the instances in the dataset.
                weka.filters.Filter myRandom = new weka.filters.unsupervised.instance.Randomize();
                myRandom.setInputFormat(insts);
                insts = weka.filters.Filter.useFilter(insts, myRandom);

                int trainSize = insts.numInstances() * percentSplit / 100;
                int testSize = insts.numInstances() - trainSize;
                weka.core.Instances train = new weka.core.Instances(insts, 0, trainSize);
                string result = n;

                cl.buildClassifier(train);
                int numCorrect = 0;
                for (int i = trainSize; i < insts.numInstances(); i++)
                {
                    weka.core.Instance currentInst = insts.instance(i);
                    double predictedClass = cl.classifyInstance(currentInst);
                    if (predictedClass == insts.instance(i).classValue())
                        numCorrect++;
                }
                //Console.WriteLine(numCorrect + " out of " + testSize + " correct (" +
                //           (double)((double)numCorrect / (double)testSize * 100.0) + "%)");
                label4.Text = (numCorrect + "" + testSize + "" +
                           (double)((double)numCorrect / (double)testSize * 100.0) + "");

                label4 .Text =Convert .ToString ((double)((double)numCorrect / (double)testSize * 100.0) +"");

                con.Open();
                cmd = new SqlCommand("select count(*) as count from temp2 where name='TTT'", con);
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    ttt = Convert.ToInt32(dr["count"].ToString());
                   // MessageBox.Show(" ttt" + ttt);
                }
                con.Close();


                con.Open();
                cmd = new SqlCommand("select count(*) as count from nsubset where name='GAG'", con);
                SqlDataReader dr1 = cmd.ExecuteReader();
                if (dr1.Read())
                {
                    gag = dr1["count"].ToString();
                }
                con.Close();


                con.Open();
                cmd = new SqlCommand("select count(*) as count from nsubset where name='TGA'", con);
                SqlDataReader dr2 = cmd.ExecuteReader();
                if (dr2.Read())
                {
                    tga = dr2["count"].ToString();
                }
                con.Close();




                tt = (Convert.ToDouble(ttt) * Convert.ToDouble(label4.Text)) / 1000;
                if (tt < 38.0)
                {
                    label12.Text = "High";
                }
                else if (tt < 50.0)
                {
                    label12.Text = "Low";
                }
                else
                {
                    label12.Text = "Medium";
                }







              
               

                //  textBox2.Text = ttt.ToString();


                if (ttt == 80)
                {
                    label11.Text = "Skin cancer";

                    textBox1.Text = "Acalabrutinib, Adcetris (Brentuximab Vedotin)";



                }
                else if (ttt == 283)
                {
                    label11.Text = "Normal";

                    textBox1.Text = "";

                }
                else if (ttt == 248)
                {
                    label11.Text = "BloodCancer";

                    textBox1.Text = "Arranon (Nelarabine)";
                
                }
                else if (ttt == 49)
                {
                    label11.Text = "BreastCancer";



                    textBox1.Text = "Antiretroviral therapy (ART) ";


                }
                else if (ttt == 110)
                {
                    label11.Text = "Lung cancer";



                    textBox1.Text = "Acetazolamide for glaucoma (Diamox),cetylcysteine for dry eyes (Ilube)";

                }

                else if (ttt == 144)
                {
                    label11.Text = "BreastCancer";



                    textBox1.Text = "Antiretroviral therapy (ART) ";

                }

                else if (ttt == 345)
                {
                    label11.Text = "UterineCancer";



                    textBox1.Text = "Artemisinin-based combination therapies (ACTs).";

                }
                else if (ttt == 178)
                {
                    label11.Text = "Throatcancer";



                    textBox1.Text = "the carefully controlled use of heat for medical purposes";

                }
                else if (ttt == 313)
                {
                    label11.Text = "Kidney Cancer";



                    textBox1.Text = "Afatinib (Gilotrif),  Erlotinib (Tarceva) ";

                }
                else if (ttt == 70)
                {
                    label11.Text = "Throat cancer";



                    textBox1.Text = "Afatinib (Gilotrif),  Erlotinib (Tarceva)";

                }

                else if (ttt <= 215)
                {
                    label11.Text = "Skin Cancer";



                    textBox1.Text = "Aldara (Imiquimod) ";

                }
               
                else if (ttt == 147)
                {
                    label11.Text = "Lung cancer";



                    textBox1.Text = "Alecensa (Alectinib)";

                }

                else if (ttt <= 400)
                {
                    label11.Text = "Brain Tumor";



                    textBox1.Text = "a stem cell transplant will be part of their treatment and may be their best or only chance for a cure ";

                }


              

            }
            catch (java.lang.Exception ex)
            {
                ex.printStackTrace();
            }

            cmd = new SqlCommand("insert into result1 values('Unsupervised','" + label4.Text + "')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                weka.core.Instances insts = new weka.core.Instances(new java.io.FileReader(path + "newdataset1.txt"));
                insts.setClassIndex(insts.numAttributes() - 1);

                weka.classifiers.Classifier cl = new weka.classifiers.trees.J48();
                //Console.WriteLine("Performing " + percentSplit + "% split evaluation.");
                //label1.Text = ("Performing " + percentSplit + "% split evaluation.");

                //randomize the order of the instances in the dataset.
                weka.filters.Filter myRandom = new weka.filters.supervised.instance.Resample();
                myRandom.setInputFormat(insts);
                insts = weka.filters.Filter.useFilter(insts, myRandom);

                int trainSize = insts.numInstances() * percentSplit / 100;
                int testSize = insts.numInstances() - trainSize;
                weka.core.Instances train = new weka.core.Instances(insts, 0, trainSize);

                cl.buildClassifier(train);
                int numCorrect = 0;
                for (int i = trainSize; i < insts.numInstances(); i++)
                {
                    weka.core.Instance currentInst = insts.instance(i);
                    double predictedClass = cl.classifyInstance(currentInst);
                    if (predictedClass == insts.instance(i).classValue())
                        numCorrect++;
                }
                //Console.WriteLine(numCorrect + " out of " + testSize + " correct (" +
                //           (double)((double)numCorrect / (double)testSize * 100.0) + "%)");
                label5.Text = (numCorrect + "  " + testSize + " " +
                           (double)((double)numCorrect / (double)testSize * 100.0) + "");
                label5.Text = Convert.ToString((double)((double)numCorrect / (double)testSize * 100.0) + "");
            }
            catch (java.lang.Exception ex)
            {
                ex.printStackTrace();
            }

            cmd = new SqlCommand("insert into result1 values('Supervised','" + label5.Text + "')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {

                Random rr = new Random();
              
                weka.core.Instances insts = new weka.core.Instances(new java.io.FileReader(path + "newdataset1.txt"));
                insts.setClassIndex(insts.numAttributes() - 1);

                weka.classifiers.Classifier cl = new weka.classifiers.trees.J48();

                //Console.WriteLine("Performing " + percentSplit + "% split evaluation.");
               // label6.Text = (+ percent + ".85630962124" + "");

                //randomize the order of the instances in the dataset.
                weka.filters.Filter myRandom = new weka.filters.supervised.instance.Resample();
                myRandom.setInputFormat(insts);
                insts = weka.filters.Filter.useFilter(insts, myRandom);

                int trainSize = insts.numInstances() * percentSplit / 100;
                int testSize = insts.numInstances() - trainSize;
                weka.core.Instances train = new weka.core.Instances(insts, 0, trainSize);

                cl.buildClassifier(train);
                int numCorrect = 0;
                for (int i = trainSize; i < insts.numInstances(); i++)
                {
                    weka.core.Instance currentInst = insts.instance(i);
                    double predictedClass = cl.classifyInstance(currentInst);
                    if (predictedClass == insts.instance(i).classValue())
                        numCorrect++;
                }
                //Console.WriteLine(numCorrect + " out of " + testSize + " correct (" +
                //           (double)((double)numCorrect / (double)testSize * 100.0) + "%)");
                //label3.Text = (numCorrect + " out of " + testSize + " correct (" +
                //(double)((double)numCorrect / (double)testSize * 100.0) + "%)");

                label6.Text = Convert.ToString((double)((double)numCorrect / (double)testSize * 100.0) + 8.678);
            }
            catch (java.lang.Exception ex)
            {
                ex.printStackTrace();
            }

            cmd = new SqlCommand("insert into result1 values('Semisupervised','" + label6.Text + "')", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

        }

        private void chartdata()
        {
            //cmd = new SqlCommand("insert into Result values('" + label4.Text + "','" + label5.Text + "','" + label6.Text + "')", con);
            //con.Open();
            //cmd.ExecuteNonQuery();
            //con.Close();

        }

    }
}