﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GeneBasedDiseasesPrediction
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Upload up = new Upload();
            up.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Upload up = new Upload();
            up.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Training tt = new Training();
            tt.Show();

        }
    }
}
