﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;


namespace GeneBasedDiseasesPrediction
{
    public partial class TrainingSpatial : Form
    {
        public string s, name;
       
        public string n;

        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\FinalGene\Gene-Based-Diseases-Prediction\Gene-Based-Diseases-Prediction\data.mdf;Integrated Security=True;User Instance=True");
        SqlCommand cmd;


        public TrainingSpatial()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //string te;


            cmd = new SqlCommand("truncate table nsubset", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            //cmd = new SqlCommand("truncate table result1", con);
            //con.Open();
            //cmd.ExecuteNonQuery();
            //con.Close();



            try
            {
                String text = s;
                int mlenght = 3;
                string[] t = new string[text.Length - 3];
                for (int i = 0; i < text.Length - mlenght; i = i + 3)
                {
                    //String t = text.Substring(i, i + mlenght).Trim();
                    t[i] = text.Substring(i, 3);
                    //listBox1.Items.Add(t[i].ToString ());

                    String ind = t[i].Substring(0, 1);
                    String res = "";
                    String temp = "";
                    if (ind.Equals("T"))
                    {
                        temp = "T" + t[i];
                        res = TCombination(t[i]);
                    }
                    else if (ind.Equals("C"))
                    {
                        temp = "C" + t[i];
                        res = CCombination(t[i]);
                    }
                    else if (ind.Equals("A"))
                    {
                        temp = "A" + t[i];
                        res = ACombination(t[i]);
                    }
                    else if (ind.Equals("G"))
                    {
                        temp = "G" + t[i];
                        res = GCombination(t[i]);
                    }
                    Double t1 = 0;
                    Double c1 = 0;
                    Double a1 = 0;
                    Double g1 = 0;
                    //string[] ind = new string[text.Length - 8];
                    for (int j = 0; j < temp.Length; j++)
                    {
                        //ind = temp.Substring(j, j + 1);
                        ind = temp[j].ToString();

                        if (ind.Equals("T"))
                        {
                            t1 = t1 + 1;
                        }
                        else if (ind.Equals("C"))
                        {
                            c1 = c1 + 1;
                        }
                        else if (ind.Equals("A"))
                        {
                            a1 = a1 + 1;
                        }
                        else if (ind.Equals("G"))
                        {
                            g1 = g1 + 1;
                        }
                    }
                    t1 = t1 / 4.0;
                    c1 = c1 / 4.0;
                    a1 = a1 / 4.0;
                    g1 = g1 / 4.0;




                    cmd = new SqlCommand("insert into nsubset values('" + t[i].ToString() + "','" + t1 + "','" + c1 + "','" + a1 + "','" + g1 + "','" + res + "')", con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();


                }

            }
            catch 
            {
               
            }




            con.Open();
            cmd = new SqlCommand("select subset,  count(subset)as Count  from nsubset where subset!='' group by subset ", con);
            SqlDataReader dr2;
            dr2 = cmd.ExecuteReader();
            while (dr2.Read())
            {

                listBox6.Items.Add(dr2["subset"].ToString() + "---->" + dr2["Count"].ToString());

            }
            con.Close();




            con.Open();
            cmd = new SqlCommand("select *  from nsubset ", con);
            SqlDataReader dr3;
            dr3 = cmd.ExecuteReader();
            while (dr3.Read())
            {

                listBox7.Items.Add(dr3["name"].ToString() + " ---> " + dr3["point1"].ToString() + "," + dr3["point2"].ToString() + "," + dr3["point3"].ToString() + "," + dr3["point4"].ToString() + "," + dr3["subset"].ToString() + "\n");

            }
            con.Close();




        }


        public String TCombination(String input)
        {
            String result = "";
            try
            {
                if (input.Equals("TTT"))
                {
                    result = "Phe";
                }
                else if (input.Equals("TTC"))
                {
                    result = "Phe";
                }
                else if (input.Equals("TTA"))
                {
                    result = "Leu";
                }
                else if (input.Equals("TTG"))
                {
                    result = "Phe";
                }
                else if (input.Equals("TCT"))
                {
                    result = "Ser";
                }
                else if (input.Equals("TCC"))
                {
                    result = "Ser";
                }
                else if (input.Equals("TCA"))
                {
                    result = "Ser";
                }
                else if (input.Equals("TCG"))
                {
                    result = "Ser";
                }
                else if (input.Equals("TAT"))
                {
                    result = "Tyr";
                }
                else if (input.Equals("TAC"))
                {
                    result = "Tyr";
                }
                else if (input.Equals("TAA"))
                {
                    result = "Stop";
                }
                else if (input.Equals("TAG"))
                {
                    result = "Stop";
                }
                else if (input.Equals("TGT"))
                {
                    result = "Cys";
                }
                else if (input.Equals("TGC"))
                {
                    result = "Cys";
                }
                else if (input.Equals("TGA"))
                {
                    result = "Stop";
                }
                else if (input.Equals("TGG"))
                {
                    result = "Trp";
                }
            }
            catch (Exception e)
            {
                e.GetBaseException();
            }
            return result;
        }

        public String CCombination(String input)
        {
            String result = "";
            try
            {
                if (input.Equals("CTT"))
                {
                    result = "Leu";
                }
                else if (input.Equals("CTC"))
                {
                    result = "Leu";
                }
                else if (input.Equals("CTA"))
                {
                    result = "Leu";
                }
                else if (input.Equals("CTG"))
                {
                    result = "Leu";
                }
                else if (input.Equals("CCT"))
                {
                    result = "Pro";
                }
                else if (input.Equals("CCC"))
                {
                    result = "Pro";
                }
                else if (input.Equals("CCA"))
                {
                    result = "Pro";
                }
                else if (input.Equals("CCG"))
                {
                    result = "Pro";
                }
                else if (input.Equals("CAT"))
                {
                    result = "His";
                }
                else if (input.Equals("CAC"))
                {
                    result = "His";
                }
                else if (input.Equals("CAA"))
                {
                    result = "Gin";
                }
                else if (input.Equals("CAG"))
                {
                    result = "Gin";
                }
                else if (input.Equals("CGT"))
                {
                    result = "Arg";
                }
                else if (input.Equals("CGC"))
                {
                    result = "Arg";
                }
                else if (input.Equals("CGA"))
                {
                    result = "Arg";
                }
                else if (input.Equals("CGG"))
                {
                    result = "Arg";
                }
            }
            catch (Exception e)
            {
                e.GetBaseException();
            }
            return result;
        }

      

        public String ACombination(String input)
        {
            String result = "";
            try
            {
                if (input.Equals("ATT"))
                {
                    result = "lle";
                }
                else if (input.Equals("ATC"))
                {
                    result = "lle";
                }
                else if (input.Equals("ATA"))
                {
                    result = "lle";
                }
                else if (input.Equals("ATG"))
                {
                    result = "Met";
                }
                else if (input.Equals("ACT"))
                {
                    result = "Thr";
                }
                else if (input.Equals("ACC"))
                {
                    result = "Thr";
                }
                else if (input.Equals("ACA"))
                {
                    result = "Thr";
                }
                else if (input.Equals("ACG"))
                {
                    result = "Thr";
                }
                else if (input.Equals("AAT"))
                {
                    result = "Asn";
                }
                else if (input.Equals("AAC"))
                {
                    result = "Asn";
                }
                else if (input.Equals("AAA"))
                {
                    result = "Lys";
                }
                else if (input.Equals("AAG"))
                {
                    result = "Lys";
                }
                else if (input.Equals("AGT"))
                {
                    result = "Ser";
                }
                else if (input.Equals("AGC"))
                {
                    result = "Ser";
                }
                else if (input.Equals("AGA"))
                {
                    result = "Arg";
                }
                else if (input.Equals("AGG"))
                {
                    result = "Arg";
                }
            }
            catch (Exception e)
            {
                e.GetBaseException();
            }
            return result;
        }

        public String GCombination(String input)
        {
            String result = "";
            try
            {
                if (input.Equals("GTT"))
                {
                    result = "Val";
                }
                else if (input.Equals("GTC"))
                {
                    result = "Val";
                }
                else if (input.Equals("GTA"))
                {
                    result = "Val";
                }
                else if (input.Equals("GTG"))
                {
                    result = "Val";
                }
                else if (input.Equals("GCT"))
                {
                    result = "Ala";
                }
                else if (input.Equals("GCC"))
                {
                    result = "Ala";
                }
                else if (input.Equals("GCA"))
                {
                    result = "Ala";
                }
                else if (input.Equals("GCG"))
                {
                    result = "Ala";
                }
                else if (input.Equals("GAT"))
                {
                    result = "Asp";
                }
                else if (input.Equals("GAC"))
                {
                    result = "Asp";
                }
                else if (input.Equals("GAA"))
                {
                    result = "Glu";
                }
                else if (input.Equals("GAG"))
                {
                    result = "Glu";
                }
                else if (input.Equals("GGT"))
                {
                    result = "Gly";
                }
                else if (input.Equals("GGC"))
                {
                    result = "Gly";
                }
                else if (input.Equals("GGA"))
                {
                    result = "Gly";
                }
                else if (input.Equals("GGG"))
                {
                    result = "Gly";
                }
            }
            catch (Exception e)
            {
                e.GetBaseException();
            }
            return result;
        }

        private void TrainingSpatial_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            NormaluserChart nn = new NormaluserChart();
            nn.Show();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Home ff = new Home();
            ff.Show();
            this.Hide();
        }



    }

        
        
}

