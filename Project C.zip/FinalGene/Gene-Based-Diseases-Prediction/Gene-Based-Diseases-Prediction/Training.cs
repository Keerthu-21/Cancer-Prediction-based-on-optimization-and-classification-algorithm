﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;


namespace GeneBasedDiseasesPrediction
{
    public partial class Training : Form
    {
        public string s;
        string name;

        public Training()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog op = new OpenFileDialog();
            op.ShowDialog();

            if (op.FileName != "")
            {
                StreamReader sr = new StreamReader(op.FileName);
                textBox1.Text = Convert.ToString(op.FileName);
                name = System.IO.Path.GetFileNameWithoutExtension(op.FileName);
                Random rrr = new Random();
                int iii = rrr.Next(10, 20);


                string strline;
                string temp;
                string r;
                while ((strline = sr.ReadLine()) != null)
                {
                    temp = strline;
                    richTextBox1.Text = temp;
                    String inputdata = temp;
                    string[] t = new string[inputdata.Length - 1];
                    int mlenght = 1;
                    for (int i = 1; i < inputdata.Length - mlenght; i++)
                    {

                        t[i] = inputdata.Substring(i, 1);

                        if (t[i].Equals("A") || t[i].Equals("C") || t[i].Equals("G") || t[i].Equals("T"))
                        {
                            if (richTextBox2.Text == "")
                            {
                                richTextBox2.Text = t[i];
                            }
                            else
                            {
                                richTextBox2.Text = richTextBox2.Text + t[i];
                            }
                        }
                    }
                }

                s = richTextBox2.Text;
            }
            //label5.Text = Convert.ToString(iii)+"%";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TrainingSpatial ss = new TrainingSpatial();
            ss.n = name;
            ss.s = s;
            ss.Show();
        }
    }
}
