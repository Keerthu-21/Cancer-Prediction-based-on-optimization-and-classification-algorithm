﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using System.Data.SqlClient;

namespace GeneBasedDiseasesPrediction
{
    public partial class BestFeatureSubset : Form
    {

        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\FinalGene\Gene-Based-Diseases-Prediction\Gene-Based-Diseases-Prediction\data.mdf;Integrated Security=True;User Instance=True");
        SqlCommand cmd;


        public string n, s;

        public BestFeatureSubset()
        {
            InitializeComponent();
        }
        int i;
        private void BestFeatureSubset_Load(object sender, EventArgs e)
        {
            i = 0;

           


            con.Open();
            cmd = new SqlCommand("select subset,  count(subset)as Count   from nsubset where subset!='' group by subset ", con);
            SqlDataReader dr2;
            dr2 = cmd.ExecuteReader();
            while (dr2.Read())
            {
                i += 1;


                if (i <= 5)
                {
                    listBox6.Items.Add(dr2["subset"].ToString() + "---->" + dr2["Count"].ToString());
                }


            }
            con.Close();
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
          

        }
    }
}
