﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;

namespace GeneBasedDiseasesPrediction
{
    public partial class Spatial : Form
    {
        public string s;
        public string n;

        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\FinalGene\Gene-Based-Diseases-Prediction\Gene-Based-Diseases-Prediction\data.mdf;Integrated Security=True;User Instance=True");
        SqlCommand cmd;
    

        public Spatial()
        {
            InitializeComponent();
        }

        public String TCombination(String input)
        {
            String result = "";
            try
            {
                if (input.Equals("TTT"))
                {
                    result = "Phe";
                }
                else if (input.Equals("TTC"))
                {
                    result = "Phe";
                }
                else if (input.Equals("TTA"))
                {
                    result = "Leu";
                }
                else if (input.Equals("TTG"))
                {
                    result = "Phe";
                }
                else if (input.Equals("TCT"))
                {
                    result = "Ser";
                }
                else if (input.Equals("TCC"))
                {
                    result = "Ser";
                }
                else if (input.Equals("TCA"))
                {
                    result = "Ser";
                }
                else if (input.Equals("TCG"))
                {
                    result = "Ser";
                }
                else if (input.Equals("TAT"))
                {
                    result = "Tyr";
                }
                else if (input.Equals("TAC"))
                {
                    result = "Tyr";
                }
                else if (input.Equals("TAA"))
                {
                    result = "Stop";
                }
                else if (input.Equals("TAG"))
                {
                    result = "Stop";
                }
                else if (input.Equals("TGT"))
                {
                    result = "Cys";
                }
                else if (input.Equals("TGC"))
                {
                    result = "Cys";
                }
                else if (input.Equals("TGA"))
                {
                    result = "Stop";
                }
                else if (input.Equals("TGG"))
                {
                    result = "Trp";
                }
            }
            catch (Exception e)
            {
                e.GetBaseException();
            }
            return result;
        }

        public String CCombination(String input)
        {
            String result = "";
            try
            {
                if (input.Equals("CTT"))
                {
                    result = "Leu";
                }
                else if (input.Equals("CTC"))
                {
                    result = "Leu";
                }
                else if (input.Equals("CTA"))
                {
                    result = "Leu";
                }
                else if (input.Equals("CTG"))
                {
                    result = "Leu";
                }
                else if (input.Equals("CCT"))
                {
                    result = "Pro";
                }
                else if (input.Equals("CCC"))
                {
                    result = "Pro";
                }
                else if (input.Equals("CCA"))
                {
                    result = "Pro";
                }
                else if (input.Equals("CCG"))
                {
                    result = "Pro";
                }
                else if (input.Equals("CAT"))
                {
                    result = "His";
                }
                else if (input.Equals("CAC"))
                {
                    result = "His";
                }
                else if (input.Equals("CAA"))
                {
                    result = "Gin";
                }
                else if (input.Equals("CAG"))
                {
                    result = "Gin";
                }
                else if (input.Equals("CGT"))
                {
                    result = "Arg";
                }
                else if (input.Equals("CGC"))
                {
                    result = "Arg";
                }
                else if (input.Equals("CGA"))
                {
                    result = "Arg";
                }
                else if (input.Equals("CGG"))
                {
                    result = "Arg";
                }
            }
            catch (Exception e)
            {
                e.GetBaseException();
            }
            return result;
        }

        private void cal()
        {
            con.Open();
            cmd = new SqlCommand("Select subset, sum(point1)as p1 ,sum(point2) as p2,sum(point3) as p3 ,sum(point4) as p4 from temp2 group by subset", con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                listBox4.Items.Add(dr["subset"].ToString() + "[TP=" + dr["p1"].ToString() + "TN=" + dr["p2"].ToString() + "FP=" + dr["p3"].ToString() + "FN=" + dr["p4"].ToString() + "]");
            }
            con.Close();
        }

        public String ACombination(String input)
        {
            String result = "";
            try
            {
                if (input.Equals("ATT"))
                {
                    result = "lle";
                }
                else if (input.Equals("ATC"))
                {
                    result = "lle";
                }
                else if (input.Equals("ATA"))
                {
                    result = "lle";
                }
                else if (input.Equals("ATG"))
                {
                    result = "Met";
                }
                else if (input.Equals("ACT"))
                {
                    result = "Thr";
                }
                else if (input.Equals("ACC"))
                {
                    result = "Thr";
                }
                else if (input.Equals("ACA"))
                {
                    result = "Thr";
                }
                else if (input.Equals("ACG"))
                {
                    result = "Thr";
                }
                else if (input.Equals("AAT"))
                {
                    result = "Asn";
                }
                else if (input.Equals("AAC"))
                {
                    result = "Asn";
                }
                else if (input.Equals("AAA"))
                {
                    result = "Lys";
                }
                else if (input.Equals("AAG"))
                {
                    result = "Lys";
                }
                else if (input.Equals("AGT"))
                {
                    result = "Ser";
                }
                else if (input.Equals("AGC"))
                {
                    result = "Ser";
                }
                else if (input.Equals("AGA"))
                {
                    result = "Arg";
                }
                else if (input.Equals("AGG"))
                {
                    result = "Arg";
                }
            }
            catch (Exception e)
            {
                e.GetBaseException();
            }
            return result;
        }

        public String GCombination(String input)
        {
            String result = "";
            try
            {
                if (input.Equals("GTT"))
                {
                    result = "Val";
                }
                else if (input.Equals("GTC"))
                {
                    result = "Val";
                }
                else if (input.Equals("GTA"))
                {
                    result = "Val";
                }
                else if (input.Equals("GTG"))
                {
                    result = "Val";
                }
                else if (input.Equals("GCT"))
                {
                    result = "Ala";
                }
                else if (input.Equals("GCC"))
                {
                    result = "Ala";
                }
                else if (input.Equals("GCA"))
                {
                    result = "Ala";
                }
                else if (input.Equals("GCG"))
                {
                    result = "Ala";
                }
                else if (input.Equals("GAT"))
                {
                    result = "Asp";
                }
                else if (input.Equals("GAC"))
                {
                    result = "Asp";
                }
                else if (input.Equals("GAA"))
                {
                    result = "Glu";
                }
                else if (input.Equals("GAG"))
                {
                    result = "Glu";
                }
                else if (input.Equals("GGT"))
                {
                    result = "Gly";
                }
                else if (input.Equals("GGC"))
                {
                    result = "Gly";
                }
                else if (input.Equals("GGA"))
                {
                    result = "Gly";
                }
                else if (input.Equals("GGG"))
                {
                    result = "Gly";
                }
            }
            catch (Exception e)
            {
                e.GetBaseException();
            }
            return result;
        }


        string path;

        private void Spatial_Load(object sender, EventArgs e)
        {
            //string te;


            path = System.IO.Path.GetDirectoryName(Application.ExecutablePath.ToString()) + "\\datase\\";


            cmd = new SqlCommand("truncate table temp2", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            cmd = new SqlCommand("truncate table result1", con);
            con.Open();
            cmd.ExecuteNonQuery();
            con.Close();

            try
            {
                String text = s;
                int mlenght = 3;
                string[] t = new string[text.Length - 3];
                for (int i = 0; i < text.Length - mlenght; i = i + 3)
                {
                    //String t = text.Substring(i, i + mlenght).Trim();
                    t[i] = text.Substring(i, 3);
                    //listBox1.Items.Add(t[i].ToString ());

                    String ind = t[i].Substring(0, 1);
                    String res = "";
                    String temp = "";
                    if (ind.Equals("T"))
                    {
                        temp = "T" + t[i];
                        res = TCombination(t[i]);
                    }
                    else if (ind.Equals("C"))
                    {
                        temp = "C" + t[i];
                        res = CCombination(t[i]);
                    }
                    else if (ind.Equals("A"))
                    {
                        temp = "A" + t[i];
                        res = ACombination(t[i]);
                    }
                    else if (ind.Equals("G"))
                    {
                        temp = "G" + t[i];
                        res = GCombination(t[i]);
                    }
                    Double t1 = 0;
                    Double c1 = 0;
                    Double a1 = 0;
                    Double g1 = 0;
                    //string[] ind = new string[text.Length - 8];
                    for (int j = 0; j < temp.Length; j++)
                    {
                        //ind = temp.Substring(j, j + 1);
                        ind = temp[j].ToString();

                        if (ind.Equals("T"))
                        {
                            t1 = t1 + 1;
                        }
                        else if (ind.Equals("C"))
                        {
                            c1 = c1 + 1;
                        }
                        else if (ind.Equals("A"))
                        {
                            a1 = a1 + 1;
                        }
                        else if (ind.Equals("G"))
                        {
                            g1 = g1 + 1;
                        }
                    }
                    t1 = t1 / 4.0;
                    c1 = c1 / 4.0;
                    a1 = a1 / 4.0;
                    g1 = g1 / 4.0;

                    listBox2.Items.Add(t[i].ToString() + " ---> " + t1 + "," + c1 + "," + a1 + "," + g1 + "," + res + "\n");
                    listBox3 .Items .Add (t1 +"," + c1 + "," + a1 + ","+ g1 + ","+ res);

                    //cmd = new SqlCommand("insert into temp values('" + res + "')", con);
                    //con.Open();
                    //cmd.ExecuteNonQuery();
                    //con.Close();

                    cmd = new SqlCommand("insert into temp2 values('" + t[i].ToString () + "','"+t1+"','"+c1+"','"+a1+"','"+g1+"','"+ res+"')", con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();

                    //cmd = new SqlCommand("insert into nsubset values('" + t[i].ToString() + "','" + t1 + "','" + c1 + "','" + a1 + "','" + g1 + "','" + res + "')", con);
                    //con.Open();
                    //cmd.ExecuteNonQuery();
                    //con.Close();

                    string sPath1 = path + "newdataset.txt";

                    System.IO.StreamWriter SaveFile1 = new System.IO.StreamWriter(sPath1);
                    foreach (var item in listBox3.Items)
                    {
                        SaveFile1.WriteLine(item);
                    }

                    SaveFile1.Close();

                }


                //con.Open();
                //cmd = new SqlCommand("select distinct subset from temp2 where subset!='' ", con);
                //SqlDataReader dr;
                //dr = cmd.ExecuteReader();
                //while (dr.Read())
                //{
                //    if (textBox1.Text == "")
                //    {
                //        textBox1.Text = dr["subset"].ToString();
                //    }
                //    else
                //    {
                //        textBox1.Text = textBox1.Text + "," + dr["subset"].ToString();
                //    }
                //}
                //con.Close();


                listBox1.Items.Add("@relation Genes");
                listBox1.Items.Add("@attribute one numeric");
                listBox1.Items.Add("@attribute two numeric");
                listBox1.Items.Add("@attribute three numeric");
                listBox1.Items.Add("@attribute four numeric");
                listBox1.Items.Add("@attribute type {" + textBox1.Text + "}");
                listBox1.Items.Add("@data");



                while (listBox3.Items.Count != 0)
                {
                    for (int i = 0; i < listBox3.Items.Count; i++)
                    {
                        listBox1.Items.Add(listBox3.Items[i]);
                        listBox3.Items.Remove(listBox3.Items[i]);
                    }
                }

            }
            catch
            {
            }

            con.Open();
            cmd = new SqlCommand("select subset,  count(subset)as Count  from temp2 where subset!='' group by subset ", con);
            SqlDataReader dr1;
            dr1 = cmd.ExecuteReader();
            while (dr1.Read())
            {

                listBox5 .Items .Add (dr1["subset"].ToString ()+"---->"+dr1["Count"].ToString ());

            }
            con.Close();


            con.Open();
            cmd = new SqlCommand("select subset,  count(subset)as Count  from nsubset where subset!='' group by subset ", con);
            SqlDataReader dr2;
            dr2 = cmd.ExecuteReader();
            while (dr2.Read())
            {

                listBox6.Items.Add(dr2["subset"].ToString() + "---->" + dr2["Count"].ToString());

            }
            con.Close();




            con.Open();
            cmd = new SqlCommand("select *  from nsubset ", con);
            SqlDataReader dr3;
            dr3 = cmd.ExecuteReader();
            while (dr3.Read())
            {

                listBox7.Items.Add(dr3["name"].ToString() + " ---> " + dr3["point1"].ToString() + "," + dr3["point2"].ToString() + "," + dr3["point3"].ToString() + "," + dr3["point4"].ToString() + "," + dr3["subset"].ToString() + "\n");

            }
            con.Close();






            Normaluser n = new Normaluser();
            n.Show();
            //uploaddatachart u = new uploaddatachart();
            //u.Show();











        }


        private void button1_Click_1(object sender, EventArgs e)
        {
            cal();
            //const string sPath = "D:\\save.txt";
            string sPath = path + "newdataset.txt";

            System.IO.StreamWriter SaveFile = new System.IO.StreamWriter(sPath);
            foreach (var item in listBox4.Items)
            {
                SaveFile.WriteLine(item);
            }

            SaveFile.Close();

            //MessageBox.Show("Programs saved!");



            listBox1.Items.Clear();

            //con.Open();
            //cmd = new SqlCommand("select distinct subset from temp2 where subset!='' ", con);
            //SqlDataReader dr;
            //dr = cmd.ExecuteReader();
            //while (dr.Read())
            //{
            //    if (textBox1.Text == "")
            //    {
            //        textBox1.Text = dr["subset"].ToString();
            //    }
            //    else
            //    {
            //        textBox1.Text = textBox1.Text + "," + dr["subset"].ToString();
            //    }
            //}


            //textBox1.Text = textBox1.Text + ",";
            //con.Close();


            listBox1.Items.Add("@relation Genes");
            listBox1.Items.Add("@attribute one numeric");
            listBox1.Items.Add("@attribute two numeric");
            listBox1.Items.Add("@attribute three numeric");
            listBox1.Items.Add("@attribute four numeric");
            listBox1.Items.Add(textBox1.Text);
            listBox1.Items.Add("@data");

            con.Open();
            cmd = new SqlCommand("select * from temp2 where subset!='' ", con);
            SqlDataReader dr1;
            dr1 = cmd.ExecuteReader();
            while (dr1.Read())
            {

                listBox1.Items.Add(dr1["point1"].ToString() + "," + dr1["Point2"].ToString() + "," + dr1["point3"].ToString() + "," + dr1["point4"].ToString() + "," + dr1["subset"].ToString());
               
            }
            con.Close();





            string sPath1 = path + "newdataset1.txt";

            System.IO.StreamWriter SaveFile1 = new System.IO.StreamWriter(sPath1);
            foreach (var item in listBox1.Items)
            {
                SaveFile1.WriteLine(item);
            }

            SaveFile1.Close();




          




        }

        private void button2_Click(object sender, EventArgs e)
        {

            cal();

            string sPath1 = path + "newdataset1.txt";
            string sPath = path + "newdataset.txt";
            try
            {


                File.Delete(sPath1);
                File.Delete(sPath);
            }
            catch (IOException ioExp)
            {
                Console.WriteLine(ioExp.Message);
            }






            System.IO.StreamWriter SaveFile = new System.IO.StreamWriter(sPath);
            foreach (var item in listBox4.Items)
            {
                SaveFile.WriteLine(item);
            }

            SaveFile.Close();





            listBox1.Items.Clear();



            listBox1.Items.Add("@relation Genes");
            listBox1.Items.Add("@attribute one numeric");
            listBox1.Items.Add("@attribute two numeric");
            listBox1.Items.Add("@attribute three numeric");
            listBox1.Items.Add("@attribute four numeric");
            listBox1.Items.Add(textBox1.Text);
            listBox1.Items.Add("@data");

            con.Open();
            cmd = new SqlCommand("select * from temp2 where subset!='' ", con);
            SqlDataReader dr1;
            dr1 = cmd.ExecuteReader();
            while (dr1.Read())
            {

                listBox1.Items.Add(dr1["point1"].ToString() + "," + dr1["Point2"].ToString() + "," + dr1["point3"].ToString() + "," + dr1["point4"].ToString() + "," + dr1["subset"].ToString());

            }
            con.Close();







            System.IO.StreamWriter SaveFile1 = new System.IO.StreamWriter(sPath1);
            foreach (var item in listBox1.Items)
            {
                SaveFile1.WriteLine(item);
            }

            SaveFile1.Close();




            CNN k = new CNN();
            k.file = s;
            k.n = n;

            k.Show();

            BestFeatureSubset ss = new BestFeatureSubset();
            ss.s = s;
            ss.n = n;
            ss.Show();

        }


        



    }
}
