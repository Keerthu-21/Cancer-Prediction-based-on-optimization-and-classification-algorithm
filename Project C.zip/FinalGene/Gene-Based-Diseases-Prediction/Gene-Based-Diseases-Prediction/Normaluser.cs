﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms.DataVisualization.Charting;

namespace GeneBasedDiseasesPrediction
{
    public partial class Normaluser : Form
    {
        public Normaluser()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\FinalGene\Gene-Based-Diseases-Prediction\Gene-Based-Diseases-Prediction\data.mdf;Integrated Security=True;User Instance=True");
        SqlCommand cmd;
        string s, s1, nn1, nn2;




        private void BindChart()
        {







            string conString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\FinalGene\Gene-Based-Diseases-Prediction\Gene-Based-Diseases-Prediction\data.mdf;Integrated Security=True;User Instance=True";
            SqlConnection conn = new SqlConnection(conString);
            DataSet ds = new DataSet();
            try
            {
                conn.Open();
                cmd = new SqlCommand("select subset,  count(subset)as Count  from nsubset where subset!='' group by subset", conn);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                da.Fill(ds, "nsubset");
                chart1.DataSource = ds.Tables["nsubset"];
                chart1.Series["Normal Person"].XValueMember = "subset";
                chart1.Series["Normal Person"].YValueMembers = "Count";


                // Set the chart title
                this.chart1.Titles.Add("Normal User");
                //// Set chart type like Bar chart, Pie chart 
                chart1.Series["Normal Person"].ChartType = SeriesChartType.Point;
                // To show chart value           
                chart1.Series["Normal Person"].IsValueShownAsLabel = true;
                //chart1.Series["Series2"].IsValueShownAsLabel = true
                //label1.Text = n;



                cmd = new SqlCommand("select subset,  count(subset)as Count  from nsubset where subset!='' group by subset", conn);
                SqlDataAdapter da1 = new SqlDataAdapter();

                DataTable dt = new DataTable();
                da.Fill(dt);

                dt.Columns.Add("col1");

                DataTable dt2 = new DataTable();
                dt2.Columns.Add("col2");

                for (int i = 0; i < 10; i++)
                {
                    DataRow dr = dt.NewRow();
                    DataRow dr2 = dt2.NewRow();

                    dr[0] = i.ToString();
                    dr2[0] = (i * i).ToString();

                    dt.Rows.Add(dr);
                    dt2.Rows.Add(dr2);
                }

                if (chart1.Series.Count > 0)
                {
                    for (int i = chart1.Series.Count - 1; i >= 0; i--)
                        chart1.Series[i].Dispose();
                }

                chart1.Series.Clear();

                chart1.Series.Add("dt");
                chart1.Series.Add("dt2");

                chart1.Series[0].Points.DataBindY(dt.DefaultView);
                chart1.Series[1].Points.DataBindY(dt2.DefaultView);
            }











            catch (Exception ex)
            {
                //Exception Message
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }




        }

        private void Normaluser_Load(object sender, EventArgs e)
        {
            //BindChart();
            //BindChart1();
            //start();

            //stsada();

            merrege();
        }

        private void BindChart1()
        {


            string conString = (@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\FinalGene\Gene-Based-Diseases-Prediction\Gene-Based-Diseases-Prediction\data.mdf;Integrated Security=True;User Instance=True");
            SqlConnection conn = new SqlConnection(conString);
            DataSet ds = new DataSet();
            try
            {
                conn.Open();
                cmd = new SqlCommand("select subset,  count(subset)as Count  from temp2 where subset!='' group by subset", conn);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                da.Fill(ds, "temp2");
                chart1.DataSource = ds.Tables["temp2"];
                chart1.Series["Upload Data"].XValueMember = "subset";
                chart1.Series["Upload Data"].YValueMembers = "Count";


                // Set the chart title
                this.chart1.Titles.Add("Uplod Dataset");
                //// Set chart type like Bar chart, Pie chart 
                chart1.Series["Upload Data"].ChartType = SeriesChartType.Point;
                // To show chart value           
                chart1.Series["Upload Data"].IsValueShownAsLabel = true;
                //chart1.Series["Series2"].IsValueShownAsLabel = true;
                //label1.Text = n;
            }
            catch (Exception ex)
            {
                //Exception Message
            }
            finally
            {
                conn.Close();
                conn.Dispose();
            }





        }


        private void start()
        {


            string connetionString = null;
            SqlConnection connection;
            SqlCommand command;
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int i = 0;
            string firstSql = null;
            string secondSql = null;

            connetionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\FinalGene\Gene-Based-Diseases-Prediction\Gene-Based-Diseases-Prediction\data.mdf;Integrated Security=True;User Instance=True";
            firstSql = "select subset,  count(subset)as Count  from nsubset where subset!='' group by subset";
            secondSql = "select subset,  count(subset)as Count  from temp2 where subset!='' group by subset";
            connection = new SqlConnection(connetionString);

            try
            {
                connection.Open();

                command = new SqlCommand(firstSql, connection);
                adapter.SelectCommand = command;
                adapter.Fill(ds, "nsubset");
                //chart1.DataSource = ds.Tables["nsubset"];
                //chart1.Series["Normal Person"].XValueMember = "subset";
                //chart1.Series["Normal Person"].YValueMembers = "Count";



                command = new SqlCommand(secondSql, connection);
                adapter.SelectCommand = command;
                //adapter.SelectCommand.CommandText = secondSql ;
                adapter.Fill(ds, "temp2");
                //chart1.DataSource = ds.Tables["temp2"];
                //chart1.Series["Upload Data"].XValueMember = "subset";
                //chart1.Series["Upload Data"].YValueMembers = "Count";

                adapter.Dispose();
                command.Dispose();
                connection.Close();
                chart1.DataSource = ds.Tables["nsubset"];
                this.chart1.Titles.Add("Normal User");
                this.chart1.Titles.Add("Uplod Dataset");
                //retrieve first table data 
                for (i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                {

                    //MessageBox.Show(ds.Tables[0].Rows[i].ItemArray[0] + " -- " + ds.Tables[0].Rows[i].ItemArray[1]);


                    chart1.Series["Normal Person"].XValueMember = "subset";

                    chart1.Series["Normal Person"].YValueMembers = "Count";
                    s = ds.Tables[0].Rows[i].ItemArray[0].ToString();
                    nn1 = ds.Tables[0].Rows[i].ItemArray[1].ToString();

                    // Set the chart title

                    //// Set chart type like Bar chart, Pie chart 
                    chart1.Series["Normal Person"].ChartType = SeriesChartType.Point;
                    // To show chart value           
                    chart1.Series["Normal Person"].IsValueShownAsLabel = true;
                    //chart1.Series["Series2"].IsValueShownAsLabel = true



                }
                //retrieve second table data 
                for (i = 0; i <= ds.Tables[1].Rows.Count - 1; i++)
                {
                    //MessageBox.Show(ds.Tables[1].Rows[i].ItemArray[0] + " -- " + ds.Tables[1].Rows[i].ItemArray[1]);

                    chart1.Series["Upload Data"].XValueMember = "subset";
                    chart1.Series["Upload Data"].YValueMembers = "Count";
                    s1 = ds.Tables[1].Rows[i].ItemArray[0].ToString();
                    nn2 = ds.Tables[1].Rows[i].ItemArray[1].ToString();

                    // Set the chart title

                    //// Set chart type like Bar chart, Pie chart 
                    chart1.Series["Upload Data"].ChartType = SeriesChartType.Point;
                    // To show chart value           
                    chart1.Series["Upload Data"].IsValueShownAsLabel = true;
                    connection.Open();
                    cmd = new SqlCommand("insert into temp3 values('" + s + "','" + s1 + "','" + nn1 + "','" + nn2 + "')", connection);
                    //con.Open();
                    cmd.ExecuteNonQuery();
                    connection.Close();
                    //con.Close();


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection ! ");
            }
        }





        private void stsada()
        {


            string connetionString = null;
            SqlConnection connection;
            SqlCommand command;
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataSet ds = new DataSet();
            int i = 0;
            string firstSql = null;
            string secondSql = null;

            connetionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\FinalGene\Gene-Based-Diseases-Prediction\Gene-Based-Diseases-Prediction\data.mdf;Integrated Security=True;User Instance=True";
            firstSql = "select subset,  count(subset)as Count  from nsubset where subset!='' group by subset";
            secondSql = "select subset,  count(subset)as Count  from temp2 where subset!='' group by subset";
            connection = new SqlConnection(connetionString);

            try
            {
                connection.Open();

                command = new SqlCommand(firstSql, connection);
                adapter.SelectCommand = command;
                adapter.Fill(ds, "nsubset");

                adapter.SelectCommand.CommandText = secondSql;
                adapter.Fill(ds, "temp2");

                adapter.Dispose();
                command.Dispose();
                connection.Close();

                chart1.DataSource = ds.Tables["nsubset"];
                chart1.DataSource = ds.Tables["temp2"];
                this.chart1.Titles.Add("Normal User");
                this.chart1.Titles.Add("Uplod Dataset");
                //retrieve first table data 
                for (i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                {

                    chart1.Series["Normal Person"].XValueMember = "subset";

                    chart1.Series["Normal Person"].YValueMembers = "Count";

                    chart1.Series["Normal Person"].ChartType = SeriesChartType.Point;
                    // To show chart value           
                    chart1.Series["Normal Person"].IsValueShownAsLabel = true;


                    //MessageBox.Show(ds.Tables[0].Rows[i].ItemArray[0] + " -- " + ds.Tables[0].Rows[i].ItemArray[1]);
                }
                //retrieve second table data 
                for (i = 0; i <= ds.Tables[1].Rows.Count - 1; i++)
                {
                    chart1.Series["Upload Data"].XValueMember = "subset";
                    chart1.Series["Upload Data"].YValueMembers = "Count";
                    chart1.Series["Upload Data"].ChartType = SeriesChartType.Point;

                    chart1.Series["Upload Data"].IsValueShownAsLabel = true;
                    //MessageBox.Show(ds.Tables[1].Rows[i].ItemArray[0] + " -- " + ds.Tables[1].Rows[i].ItemArray[1]);


                    // connection.Open();
                    //cmd = new SqlCommand("insert into temp3 values('" + s + "','" + s1 + "','" + nn1 + "','" + nn2 + "')", connection);
                    ////con.Open();
                    //cmd.ExecuteNonQuery();
                    //connection.Close();

                }


            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection ! ");
            }
        }


        private void merrege()
        {
            string connetionString = null;
            SqlConnection connection;
            SqlCommand command;
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataSet ds = new DataSet();
            DataTable dt;
            string firstSql = null;
            string secondSql = null;
            int i = 0;
            connetionString = @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\FinalGene\Gene-Based-Diseases-Prediction\Gene-Based-Diseases-Prediction\data.mdf;Integrated Security=True;User Instance=True";
            firstSql = "select subset as ss1,  count(subset)as Count  from nsubset where subset!='' group by subset";
            secondSql = "select subset as s1,  count(subset)as Count1  from temp2 where subset!='' group by subset";
            //connection = new SqlConnection(connetionString);

            connection = new SqlConnection(connetionString);
            //try
            //{
            connection.Open();
            command = new SqlCommand(firstSql, connection);
            adapter.SelectCommand = command;
            adapter.Fill(ds, "Table(0)");
            adapter.SelectCommand.CommandText = secondSql;
            adapter.Fill(ds, "Table(1)");
            adapter.Dispose();
            command.Dispose();
            connection.Close();
            chart1.DataSource = ds.Tables["Table(0)"];
            //chart1.DataSource = ds.Tables["Table(1)"];
            this.chart1.Titles.Add("Normal User");
            this.chart1.Titles.Add("Uplod Dataset");

            ds.Tables[0].Merge(ds.Tables[1]);
            dt = ds.Tables[0];

            for (i = 0; i <= dt.Rows.Count - 1; i++)
            {
                //MessageBox.Show(dt.Rows[i].ItemArray[0] + " -- " + dt.Rows[i].ItemArray[1]);
                chart1.Series["Normal Person"].XValueMember = "ss1";

                chart1.Series["Normal Person"].YValueMembers = "Count";
                chart1.Series["Normal Person"].ChartType = SeriesChartType.Line;

                chart1.Series["Upload Data"].XValueMember = "s1";
                chart1.Series["Upload Data"].YValueMembers = "Count1";
                chart1.Series["Upload Data"].ChartType = SeriesChartType.Line;

                chart1.Series["Upload Data"].IsValueShownAsLabel = true;
            }
        }
        //catch (Exception ex)
        //{
        //    MessageBox.Show("Can not open connection ! ");
        //}

    }









}









